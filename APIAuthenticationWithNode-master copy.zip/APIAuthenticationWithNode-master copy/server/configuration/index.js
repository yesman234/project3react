if (process.env.NODE_ENV === 'test') {
  module.exports = {
    JWT_SECRET: 'codeworkrauthentication',
    oauth: {
      google: {
        clientID: 'number',
        clientSecret: 'string',
      },
      facebook: {
        clientID: 'number',
        clientSecret: 'string',
      },
    },
  };
} else {
  module.exports = {
    JWT_SECRET: 'codeworkrauthentication',
    oauth: {
      google: {
        clientID: '641387140165',
        clientSecret: 'Bfzg8QGYGWRR1r6qMxNsxaAn',
      },
      facebook: {
        clientID: '1065850710274087',
        clientSecret: '5dac36442cc1f9f86a592586b5be232c',
      },
    },
  };
}