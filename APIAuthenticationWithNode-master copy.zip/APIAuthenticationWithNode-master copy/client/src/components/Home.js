import React from 'react';

export default () => {
  return (
    <div>
      Welcome to our home page!
    </div>
  );
};