export const AUTH_SIGN_UP = 'AUTH_SIGN_UP';
export const AUTH_SIGN_OUT = 'AUTH_SIGN_OUT';
export const AUTH_SIGN_IN = 'AUTH_SIGN_IN';
export const AUTH_ERROR = 'AUTH_ERROR';
export const DASHBOARD_GET_DATA = 'DASHBOARD_GET_DATA';
